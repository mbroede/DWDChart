DATENQUELLE:
Deutscher Wetterdienst, Climate Data Center (CDC).

ZITIEREN MIT:
Daten extrahiert vom DWD Climate Data Center (CDC): Titel, Version, Datum.
Beachten Sie die Nutzungsbedingungen in https://opendata.dwd.de/climate_environment/CDC/Nutzungsbedingungen_German.pdf.
Auf der Webseite des Deutschen Wetterdienstes sind die Nutzungsbedingungen und Quellenangaben ausführlich erklärt.

KONTAKT:
Deutscher Wetterdienst
CDC - Vertrieb Klima und Umwelt
Frankfurter Straße 135
63067 Offenbach
Tel.: + 49 (0) 69 8062-4400
Fax.: + 49 (0) 69 8062-4499
email: klima.vertrieb@dwd.de